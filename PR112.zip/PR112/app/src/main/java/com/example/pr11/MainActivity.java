package com.example.pr11;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Method referenced in the Button's android:onClick attribute
    public void showSelected(View view) {
        // Find the CheckBoxes by their IDs
        CheckBox chkAndroid = findViewById(R.id.chkAndroid);
        CheckBox chkJava = findViewById(R.id.chkJava);
        CheckBox chkPhp = findViewById(R.id.chkPhp);
        CheckBox chkCpp = findViewById(R.id.chkCpp);
        CheckBox chkC = findViewById(R.id.chkC);

        // Build a string of selected options
        StringBuilder selectedOptions = new StringBuilder("Selected: ");
        if (chkAndroid.isChecked()) selectedOptions.append("Android ");
        if (chkJava.isChecked()) selectedOptions.append("Java ");
        if (chkPhp.isChecked()) selectedOptions.append("PHP ");
        if (chkCpp.isChecked()) selectedOptions.append("C++ ");
        if (chkC.isChecked()) selectedOptions.append("C ");

        // Display the selected options in a Toast
        Toast.makeText(this, selectedOptions.toString(), Toast.LENGTH_SHORT).show();
    }
}